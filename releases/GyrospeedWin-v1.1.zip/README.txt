GyrospeedWin
------------

GyrospeedWin is a C#/.NET Windows replacement for the native Commodore 64
Gyrospeed turbo tape program written by Gary Saunders. It simplifies the
creation of turbo tape (.TAP) images from crunched PRG files, which can be
recorded back to cassette tape for use on real hardware. The Gyrospeed loader
is one of the quickest turbos around, with many crunched games loading in
around 20 - 30 counts of the datasette counter.

The original Gyrospeed program was included as a type-in listing in the
April 1988 issue of Your Commodore magazine. This zip file contains a .D64
image containing the original program. The magazine issue can be viewed on
the Internet Archive here:

https://archive.org/details/YourCommodore80Jun91/YourCommodore/YourCommodore43-Apr88/page/n67/mode/2up

Usage
-----

GyrospeedWin <crunched-prg-file> -or- <folder-containing-crunched-prgs>

Alternatively, you can simply drag and drop a PRG file or a folder containing
PRG files onto the executable filename in Windows Explorer.

The crunched PRG files should have a BASIC SYS line at $0801 to run the program
(e.g. crunched with Exomizer etc) and can be loaded into the address range
$0400 - $cfff.

Features
--------

* Fixes the issue with the original Gyrospeed where it did not clear the
  keyboard buffer before starting the crunched program
  
* Supports processing either a single PRG file or batch processing all PRGs in
  a given folder (drag and drop)

* Can automatically build optimised compilation TAP files based on a given
  cassette tape length in minutes 

* Supports 20 different loading effects such as the classsic FreeLoad colour
  cycling from the Ocean Loader, as well an option for randomised effect
  selection
  
* Supports both the standard and clear screen found message styles, as well as
  selected or randomised text colour

* Includes full C# and 6502 assembly sourcecode

Thanks
------

Special thanks go out to the following people for their contributions and
support:

* ricky006 for introducing me to the original Gyrospeed program and providing
  invaluable testing on real hardware
  
* SLC (the author of TapEx) for his fantastic help with some questions I had about
  the .TAP format

* Richard of TND for providing additional loading effects, including a couple of
  amusing ones! ;)

* Neo-Rio for suggestions and nagging me to get the updated version released! :p

StatMat - December 2020
