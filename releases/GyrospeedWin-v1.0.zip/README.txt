GyrospeedWin
------------

GyrospeedWin is a C#/.NET Windows replacement for the native Commodore 64
Gyrospeed application written by Gary Saunders. It simplifies the creation of
turbo tapes (.TAP) images from crunched PRG files, which can either be used
in emulators, or recorded back to cassette tape for use on real hardware.

The original Gyrospeed application was included as a type-in listing in the
April 1988 issue of Your Commodore magazine. This zip file has a .D64 image
containing a PRG of the original application. The magazine issue can be
viewed on the Internet Archive here:

https://archive.org/details/YourCommodore80Jun91/YourCommodore/YourCommodore43-Apr88/page/n67/mode/2up

Usage
-----

GyrospeedWin <crunched-prg-file> -or- <folder-containing-crunched-prgs>

The crunched PRG files should have a BASIC SYS line at $0801 to run the program
(e.g. crunched with Exomizer etc) and can be loaded into the address range
$0400 - $cfff.

Features
--------

* Fixes the issue with the original Gyrospeed where it did not clear the
  keyboard buffer before starting the crunched program
  
* Supports processing either a single PRG file or batch processing all PRGs in
  a given folder (drag and drop)

* Supports 10 different loading effects, including an option for randomised
  selection

* Includes full C# and 6502 assembler sourcecode

Special thanks go out to the following people for their contributions and
support:

* ricky006 for introducing me to the original Gyrospeed program and providing
  invaluable testing on real hardware
  
* SLC (author of TapEx) for his fantastic help with some questions I had about
  the .TAP format

StatMat - November 2020
